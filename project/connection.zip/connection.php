<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "phpreviews";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$sql = "
CREATE TABLE IF NOT EXISTS `register_users` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `name` TEXT NOT NULL,
    `email` TEXT NOT NULL,
    `password` TEXT NOT NULL,
    `status` TEXT NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";
$conn->query($sql);




$sqlthree = "
CREATE TABLE IF NOT EXISTS `moneymade`(
	`id` int(11) NOT NULL AUTO_INCREMENT,
	`uid` TEXT NOT NULL,
	`tdate` TEXT NOT NULL,
	`made` TEXT NOT NULL,
	`lost` TEXT NOT NULL,
	 PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";
$conn->query($sqlthree);

$sqlfour = "
CREATE TABLE IF NOT EXISTS `goal`(
	`id` int(11) NOT NULL AUTO_INCREMENT,
	`uid` TEXT NOT NULL ,
	`gdate` TEXT NOT NULL ,
	`ear` TEXT NOT NULL ,
	 PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";
$conn->query($sqlfour);




?>